<?php

namespace App\Services;

use App\Models\Explanation;
use App\Models\OrderExplanation;
use App\Models\Title;
use App\Repositories\EducationRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EducationService
    {
        protected $educationRepository;
        private $validationService;

        public function __construct(EducationRepository $educationRepository, ValidationService $validationService)
        {
            $this->educationRepository = $educationRepository;
            $this->validationService = $validationService;
        }

        public function getAllClassroom()
        {
            return $this->educationRepository->getAllClassroom();
        }

        public function getSubjectsForClassroom($classroomId)
        {
            return $this->educationRepository->getSubjectsForClassroom($classroomId);
        }



    public function getTitlesForSubjectClass($subjectClassId)
    {
        return $this->educationRepository->getTitlesForSubjectClass($subjectClassId);
    }

    public function orderExplanations(array $data)
    {
        $this->validationService->validateorderExplanations($data);
        return $this->educationRepository->orderExplanations($data);
    }


    public function approveorderExplanation($orderId)
    {
        try {
        $orderExplanation=$this->educationRepository->findOrderExplanationById($orderId);
        if (!$orderExplanation) {
            throw new \Exception('لم يتم العثور على الطلب.');
        }

        if ($orderExplanation->approvals >=3) {
            throw new \Exception('الحد الأقصى للموافقات على الطلب قد تم تجاوزه.');
        }
        $explanation =$this->educationRepository->createExplanation($orderId,$orderExplanation);
        $orderExplanation=$this->educationRepository->updateApprovalsCount($orderExplanation);

        return $explanation;
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }
    public function getAllOrderExplanations()
    {
        return $this->educationRepository->getAllOrderExplanations();
    }




    public function getChildOrderExplanations()
    {
//        $loggedInChildId = Auth::id();
        $loggedInChildId=1;
        return $this->educationRepository->getChildOrderExplanations($loggedInChildId);
    }

    public function OrderExplanationDetails($id)
    {
        return $this->educationRepository->OrderExplanationDetails($id);
    }

    public function getUserPendingExplanations()
    {
//        $userId = Auth::id();
        $userId=1;

        return $this->educationRepository->getUserPendingExplanations($userId);
    }

    public function getUserUploadedExplanations()
    {
//        $userId = Auth::id();
        $userId=1;

        return $this->educationRepository->getUserUploadedExplanations($userId);
    }

    public function getUserRejectedExplanations()
    {
//        $userId = Auth::id();
        $userId=1;

        return $this->educationRepository->getUserRejectedExplanations($userId);
    }

    public function getUserApprovedExplanations()
    {
//        $userId = Auth::id();
        $userId=1;

        return $this->educationRepository->getUserApprovedExplanations($userId);
    }

    public function getExplanationsByTitle($titleId)
    {
        return $this->educationRepository->getExplanationsByTitle($titleId);
    }

}
