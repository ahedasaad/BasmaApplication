<?php
namespace App\Repositories;

use App\Http\Resources\SubjectForClassroom;
use App\Http\Resources\TitleResource;
use App\Models\Classroom;
use App\Models\Explanation;
use App\Models\OrderExplanation;
use App\Models\Subject;
use App\Models\SubjectClass;
use App\Models\Title;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;


class EducationRepository
{

    public function getAllClassroom()
    {
        return Classroom::all();
    }


    public function getSubjectsForClassroom($classroomId)
    {
        $subjectClasses = SubjectClass::where('classroom_id', $classroomId)
            ->with('subject:id,name')
            ->get();

        return SubjectForClassroom::collection($subjectClasses);
    }

    public function getTitlesForSubjectClass($subjectClassId)
    {
        $subjectClass = SubjectClass::findOrFail($subjectClassId);
        $titles = $subjectClass->titles;
        return TitleResource::collection($titles);

    }

    // في الريبوزيتوري
    public function orderExplanations(array $data)
    {
        // تحديد حالة الطلب إلى "pending" إذا لم يتم تقديمها في البيانات
        if (!isset($data['state'])) {
            $data['state'] = 'pending';
        }
        $order = OrderExplanation::create($data);
//        $order->state = $data['state'];

        return $order;
    }

    public function findOrderExplanationById($id)
    {
        return OrderExplanation::find($id);
    }

    public function updateApprovalsCount($orderExplanation)
    {
        if ($orderExplanation->state == 'pending') {
            $orderExplanation->state = 'approved';
        }
        $orderExplanation->approvals++;
        return $orderExplanation->save();
    }



    public function createExplanation($orderId,$request)
    {
        if (!$request) {
            throw new \Exception('لم يتم العثور على الطلب.');
        }

        // **إنشاء شرح جديد**
        $explanation = new Explanation;
        $explanation->order_explanation_id = $request->id;
        // $explanation->user_id = auth()->user()->id;
        $explanation->user_id = 1;
        $explanation->video = "fff**************************************";
        $explanation->title_id = $request->title_id;
        $explanation->title = 'شرح بدون عنوان';
        $explanation->save();

        return $explanation;
    }


    public function getAllOrderExplanations()
    {
        return OrderExplanation::where('state', 'pending')->orderBy('created_at', 'asc')
            ->union(
                OrderExplanation::where('state', 'approved')->where('approvals', 1)->orderBy('created_at', 'asc')
            )->union(
                OrderExplanation::where('state', 'approved')->where('approvals', 2)->orderBy('created_at', 'asc')
            )->union(
                OrderExplanation::where('state', 'approved')->where('approvals', '<', 3)->orderBy('created_at', 'asc')
            )->get();
    }



    public function getChildOrderExplanations($loggedInChildId)
    {
        return OrderExplanation::where('user_id', $loggedInChildId)->orderByRaw("state = 'approved' DESC")->get();
    }

    public function OrderExplanationDetails($id)
    {
        return OrderExplanation::findOrFail($id);
    }

    public function getUserPendingExplanations($userId)
    {
        return Explanation::where('user_id', $userId)
            ->where('state', 'pending')
            ->orderBy('created_at', 'asc')
            ->get();
    }

    public function getUserUploadedExplanations($userId)
    {
        return Explanation::where('user_id', $userId)
            ->where('state', 'uploaded')
            ->orderBy('created_at', 'asc')
            ->get();
    }


    public function getUserRejectedExplanations($userId)
    {
        return Explanation::where('user_id', $userId)
            ->where('state', 'rejected')
            ->orderBy('created_at', 'asc')
            ->get();
    }


    public function getUserApprovedExplanations($userId)
    {
        return Explanation::where('user_id', $userId)
            ->where('state', 'approved')
            ->orderBy('created_at', 'asc')
            ->get();
    }

    public function getExplanationsByTitle($titleId)
    {
        return Explanation::where('title_id', $titleId)
            ->where('state', 'approved')
            ->get();
    }
}
