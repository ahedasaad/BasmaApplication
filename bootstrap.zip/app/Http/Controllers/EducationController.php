<?php

namespace App\Http\Controllers;

use App\Models\Explanation;
use App\Models\OrderExplanation;
use App\Models\Title;

use App\Services\EducationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//use Cloudinary\Cloudinary;
use Cloudinary\Api\Admin\AdminApi;
use CloudinaryLabs\CloudinaryLaravel\Facades\Cloudinary;
use CloudinaryLabs\CloudinaryLaravel\CloudinaryEngine;


use Cloudinary\Api\Upload\UploadApi;
use Cloudinary\Configuration\Configuration;

use Cloudinary\Configuration\UrlConfig;
use Illuminate\Support\Facades\Http;
use Spatie\FlareClient\Http\Client;


class EducationController extends Controller
{
    protected $educationService;

    public function __construct(EducationService $educationService)
    {
        $this->educationService = $educationService;
    }

    public function getAllClassroom()
    {
        try {
            $classroom = $this->educationService->getAllClassroom();
            return response()->json($classroom);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function getSubjectsForClassroom($classroomId)
    {
        try {

            $subjects = $this->educationService->getSubjectsForClassroom($classroomId);
            return response()->json($subjects);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    // EducationController.php

    public function getTitlesForSubjectClass($subjectClassId)
    {
        $titles = $this->educationService->getTitlesForSubjectClass($subjectClassId);

        return response()->json($titles);
    }

    public function orderExplanations(Request $request)
    {


        return $this->educationService->orderExplanations($request->all());
    }

    public function approveorderExplanation($orderId, Request $request)
    {

        try {

            $explanation = $this->educationService->approveorderExplanation($orderId);
            return response()->json($explanation);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }


    }

    public function getAllOrderExplanations()
    {
        try {
            $explanations = $this->educationService->getAllOrderExplanations();
            return response()->json($explanations);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }


    public function getChildOrderExplanations()
    {

        try {
            $explanations = $this->educationService->getChildOrderExplanations();
            return response()->json($explanations);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function OrderExplanationDetails($id)
    {
        try {
            $orderExplanation = $this->educationService->OrderExplanationDetails($id);
            return response()->json($orderExplanation);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function getUserPendingExplanations()
    {
        try {
            $explanations = $this->educationService->getUserPendingExplanations();
            return response()->json($explanations);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }

    }

    public function getUserUploadedExplanations()
    {
        try {
            $explanations = $this->educationService->getUserUploadedExplanations();
            return response()->json($explanations);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }

    }

    public function getUserRejectedExplanations()
    {
        try {
            $explanations = $this->educationService->getUserRejectedExplanations();
            return response()->json($explanations);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }

    }

    public function getUserApprovedExplanations()
    {
        try {
            $explanations = $this->educationService->getUserApprovedExplanations();
            return response()->json($explanations);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }

    }

    public function getExplanationsByTitle($titleId)
    {

        try {
            $explanations = $this->educationService->getExplanationsByTitle($titleId);
            return response()->json($explanations);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function cloudinary()
    {
//        try {
//            Configuration::instance([
//                'cloud' => [
//                    'cloud_name' => config('services.cloudinary.cloud_name'),
//                    'api_key' => config('services.cloudinary.api_key'),
//                    'api_secret' => config('services.cloudinary.api_secret')
//                ]
//            ]);
//
//            // إنشاء توكن مؤقت
//            $uploadApi = new UploadApi();
//            $expiresAt = time() + 3600; // تاريخ انتهاء الصلاحية (بعد ساعة)
//            $token = Utils::generate_signed_timestamp($expiresAt);


//            Configuration::instance([
//                'cloud' => [
//                    'cloud_name' => config('services.cloudinary.cloud_name'),
//                    'api_key' => config('services.cloudinary.api_key'),
//                    'api_secret' => config('services.cloudinary.api_secret')
//                ]
//            ]);

//            // إنشاء توكن مؤقت
//            $expiresAt = time() + 3600; // تاريخ انتهاء الصلاحية (بعد ساعة)
//            $api = new UploadApi();
//            $token = $api->unsigned_image_upload(['expires_at' => $expiresAt]);


        try {
            $apiKey = config('cloudinary.api_key');
            $apiSecret = config('cloudinary.api_secret');

            $client = new Client();
            $response = $client->post("https://api.cloudinary.com/v1_1/ARWA/generate_auth_token", [
                'form_params' => [
                    'api_key' => $apiKey,
                    'api_secret' => $apiSecret,
                    'expires_at' => now()->addHours(1)->timestamp, // تحديد صلاحية التوكن
                    'allowed_formats' => ['jpg', 'jpeg', 'png', 'gif'], // الأذونات المسموح بها للتوكن
                    // يمكنك إضافة المزيد من الخيارات هنا
                ]
            ]);

            // التحقق من صحة الاستجابة
            if (!empty($response)) {
                // قراءة جسم الاستجابة كنص
                $token = $response->getBody()->getContents();

                return response()->json(['token' => $token]);
            } else {
                return response()->json(['error' => 'Failed to get token'], 500);
            }
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }


//        try {
//        // عين مفتاح وسر خدمة Cloudinary الخاص بك
//        $cloudinaryCloudName = env('CLOUDINARY_CLOUD_NAME');
//        $cloudinaryApiKey = env('CLOUDINARY_API_KEY');
//        $cloudinaryApiSecret = env('CLOUDINARY_API_SECRET');
//
//// استخدام مكتبة Cloudinary SDK لطلب التوكن المؤقت
//        $result = Cloudinary::getToken([
//            'cloud_name' => $cloudinaryCloudName,
//            'api_key' => $cloudinaryApiKey,
//            'api_secret' => $cloudinaryApiSecret
//        ]);
//
//
//// ستكون $result مصفوفة تحتوي على التوكن المؤقت وأي بيانات أخرى ذات الصلة
//        $token = $result['token'];
//        return response()->json(['token' => $token]);
//        } catch (\Exception $e) {
//            return response()->json(['error' => $e->getMessage()], 500);
//        }


    }

    public function uploadImage(Request $request)
    {
        try {

            $image = $request->file('image');
            $uploadedFileUrl = Cloudinary::uploadFile($request->file('image')->getRealPath())->getSecurePath();

            return response()->json(['token' => $uploadedFileUrl]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }


    }



//    function generateCloudinaryToken()
//    {
//        try {
//            // Initialize Cloudinary configuration with your credentials
//            Cloudinary::config([
//                'cloud_name' => env('CLOUDINARY_CLOUD_NAME'),
//                'api_key' => env('CLOUDINARY_API_KEY'),
//                'api_secret' => env('CLOUDINARY_API_SECRET')
//            ]);
//
//            // Generate a temporary authentication token
//            $token = Cloudinary::uploadApi()->generateAuthToken();
//
//            // Return the token
//            return $token;
//        } catch (\Exception $e) {
//            // Handle any exceptions that occur
//            echo "Error generating Cloudinary token: " . $e->getMessage();
//            return null;
//        }
//    }




        public function createAccessToken()
    {
        // استخراج معلومات الاعتماد من CLOUDINARY_URL
        $cloudinaryUrlParts = parse_url(env('CLOUDINARY_URL'));
        $cloudinaryConfig = [
            'cloud_name' => $cloudinaryUrlParts['host'],
            'api_key' => $cloudinaryUrlParts['user'],
            'api_secret' => $cloudinaryUrlParts['pass'],
        ];

        // استخدام معلومات الاعتماد لتهيئة تكوين CloudinaryLaravel
//        Cloudinary::config($cloudinaryConfig);

//            $accessToken=$api->create_upload_preset([
//                "name" => "ml_default",
//                "unsigned" => true,
//                "folder" => "arwa"
//            ]);

//        // إرجاع توكن الوصول للاستخدام
//        return response()->json(['token' => $accessToken]);


    }



}

